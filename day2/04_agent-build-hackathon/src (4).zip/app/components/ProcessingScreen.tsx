import { useEffect, useState } from 'react';
import { Circle, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import * as Progress from '@radix-ui/react-progress';

interface ProcessingScreenProps {
  onComplete: () => void;
}

interface LogEntry {
  type: 'question_start' | 'tool_call' | 'tool_result' | 'question_done' | 'error';
  question_id: string;
  payload: string;
  timestamp: number;
}

interface QuestionStatus {
  id: string;
  category: string;
  status: 'pending' | 'in_progress' | 'done' | 'error';
  elapsed?: number;
}

export function ProcessingScreen({ onComplete }: ProcessingScreenProps) {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [questions, setQuestions] = useState<QuestionStatus[]>([
    { id: 'Q1', category: 'technical', status: 'pending' },
    { id: 'Q2', category: 'compliance', status: 'pending' },
    { id: 'Q3', category: 'pricing', status: 'pending' },
    { id: 'Q4', category: 'technical', status: 'pending' },
    { id: 'Q5', category: 'company-info', status: 'pending' },
  ]);
  const [toolCallCount, setToolCallCount] = useState(0);

  useEffect(() => {
    const mockProcessing = async () => {
      const questionSequence = [
        { id: 'Q1', category: 'technical', time: 14000 },
        { id: 'Q2', category: 'compliance', time: 12000 },
        { id: 'Q3', category: 'pricing', time: 8000 },
        { id: 'Q4', category: 'technical', time: 16000 },
        { id: 'Q5', category: 'company-info', time: 10000 },
      ];

      for (const q of questionSequence) {
        setQuestions(prev => prev.map(item =>
          item.id === q.id ? { ...item, status: 'in_progress' } : item
        ));

        addLog({
          type: 'question_start',
          question_id: q.id,
          payload: `[${q.id} ${q.category}] Starting...`,
          timestamp: Date.now(),
        });

        await new Promise(resolve => setTimeout(resolve, 1000));

        addLog({
          type: 'tool_call',
          question_id: q.id,
          payload: `  → search_kb(query="...", category=${q.category})`,
          timestamp: Date.now(),
        });

        setToolCallCount(prev => prev + 1);

        await new Promise(resolve => setTimeout(resolve, 1500));

        addLog({
          type: 'tool_result',
          question_id: q.id,
          payload: `  ← ${Math.floor(Math.random() * 5) + 1} results returned`,
          timestamp: Date.now(),
        });

        await new Promise(resolve => setTimeout(resolve, q.time - 2500));

        addLog({
          type: 'question_done',
          question_id: q.id,
          payload: `  [DONE] ${q.id} answered in ${(q.time / 1000).toFixed(0)}s`,
          timestamp: Date.now(),
        });

        setQuestions(prev => prev.map(item =>
          item.id === q.id ? { ...item, status: 'done', elapsed: q.time / 1000 } : item
        ));
      }

      setTimeout(() => {
        onComplete();
      }, 1000);
    };

    mockProcessing();
  }, [onComplete]);

  const addLog = (entry: LogEntry) => {
    setLogs(prev => [...prev, entry]);
  };

  const completedCount = questions.filter(q => q.status === 'done').length;
  const progress = (completedCount / questions.length) * 100;

  const getLogColor = (type: string) => {
    switch (type) {
      case 'question_start':
        return 'var(--muted-foreground)';
      case 'tool_call':
        return '#60A5FA';
      case 'tool_result':
        return 'var(--success)';
      case 'question_done':
        return 'var(--brand-orange)';
      default:
        return 'white';
    }
  };

  const StatusIcon = ({ status }: { status: string }) => {
    switch (status) {
      case 'pending':
        return <Circle size={20} style={{ color: 'var(--muted-foreground)' }} />;
      case 'in_progress':
        return <Loader2 size={20} className="animate-spin" style={{ color: 'var(--brand-orange)' }} />;
      case 'done':
        return <CheckCircle2 size={20} style={{ color: 'var(--success)' }} />;
      case 'error':
        return <XCircle size={20} style={{ color: 'var(--error)' }} />;
      default:
        return <Circle size={20} />;
    }
  };

  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: 'var(--surface)' }}>
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-[60%_40%] gap-6">
          {/* Left panel - Live Agent Log */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 border-b border-border flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
              <h2>Agent running…</h2>
            </div>
            <div
              className="p-4 h-[600px] overflow-y-auto font-mono text-[13px]"
              style={{ backgroundColor: 'var(--brand-dark)', color: 'white' }}
            >
              {logs.map((log, i) => (
                <div key={i} className="mb-1" style={{ color: getLogColor(log.type) }}>
                  {log.payload}
                </div>
              ))}
            </div>
          </div>

          {/* Right panel - Progress Summary */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex flex-col items-center mb-8">
              <div className="relative w-32 h-32 mb-4">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    fill="none"
                    stroke="var(--muted)"
                    strokeWidth="8"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    fill="none"
                    stroke="var(--brand-orange)"
                    strokeWidth="8"
                    strokeDasharray={`${2 * Math.PI * 56}`}
                    strokeDashoffset={`${2 * Math.PI * 56 * (1 - progress / 100)}`}
                    strokeLinecap="round"
                    className="transition-all duration-500"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold" style={{ color: 'var(--brand-dark)' }}>
                    {completedCount}/{questions.length}
                  </span>
                </div>
              </div>
              <p style={{ color: 'var(--muted-foreground)' }}>
                ~{Math.max(0, (questions.length - completedCount) * 12)}s remaining
              </p>
            </div>

            <div className="space-y-3 mb-6">
              {questions.map(q => (
                <div key={q.id} className="flex items-center gap-3 p-3 rounded-md" style={{ backgroundColor: 'var(--surface)' }}>
                  <StatusIcon status={q.status} />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{q.id}</span>
                      <span
                        className="px-2 py-0.5 rounded text-xs uppercase tracking-wider"
                        style={{ backgroundColor: 'var(--muted)', color: 'var(--brand-dark)' }}
                      >
                        {q.category}
                      </span>
                    </div>
                    {q.elapsed && (
                      <p className="text-xs mt-1" style={{ color: 'var(--muted-foreground)' }}>
                        {q.elapsed.toFixed(0)}s
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-border pt-4">
              <p className="text-sm mb-4" style={{ color: 'var(--muted-foreground)' }}>
                {toolCallCount} KB searches made
              </p>
              <button
                className="w-full py-2 rounded-md border border-border transition-colors hover:bg-muted"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
