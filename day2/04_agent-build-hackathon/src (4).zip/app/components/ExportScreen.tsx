import { useState } from 'react';
import { Download, Copy, CheckCircle2, ChevronLeft } from 'lucide-react';
import * as RadioGroup from '@radix-ui/react-radio-group';
import * as Checkbox from '@radix-ui/react-checkbox';

interface ExportScreenProps {
  onBack: () => void;
}

const mockOutput = {
  rfp_name: "Sample RFP — Agent Engineering Challenge",
  total_questions: 5,
  answers: [
    {
      question_id: "Q1",
      category: "technical",
      answer: "Helios Sentinel employs a multi-layered approach...",
      sources: ["Helios Platform Architecture Doc v4.2"],
      confidence: "high",
      flags: []
    },
    // ... more answers
  ],
  review: {
    status: "issues_found",
    issues: [
      {
        type: "contradiction",
        questions_involved: ["Q3", "Q4"],
        description: "Pricing inconsistency..."
      }
    ],
    overall_assessment: "The responses demonstrate strong technical depth..."
  },
  metadata: {
    model: "claude-sonnet-4-20250514",
    total_time: "60s",
    tool_calls: 12,
    timestamp: "2026-05-08T10:30:00Z"
  }
};

export function ExportScreen({ onBack }: ExportScreenProps) {
  const [format, setFormat] = useState('json');
  const [includeFields, setIncludeFields] = useState({
    answers: true,
    sources: true,
    confidence: true,
    flags: true,
    review: true,
    metadata: true,
  });
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(JSON.stringify(mockOutput, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([JSON.stringify(mockOutput, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'rfp_output.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: 'var(--surface)' }}>
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 mb-6 transition-colors"
          style={{ color: 'var(--brand-orange)' }}
        >
          <ChevronLeft size={20} />
          Back to Review
        </button>

        {/* Eval Summary Bar */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="flex items-center gap-3">
            <CheckCircle2 size={24} style={{ color: 'var(--success)' }} />
            <div className="flex gap-4 text-sm">
              <span>Evals: <strong style={{ color: 'var(--success)' }}>24 passed</strong></span>
              <span>·</span>
              <span><strong>0 failed</strong></span>
              <span>·</span>
              <span style={{ color: 'var(--success)' }}>All assertions green ✓</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[40%_60%] gap-6">
          {/* Left - Export Options */}
          <div className="bg-white rounded-lg shadow-md p-6 h-fit">
            <h2 className="text-lg mb-6">Export Options</h2>

            {/* Format Selector */}
            <div className="mb-6">
              <label className="block text-sm mb-3" style={{ color: 'var(--muted-foreground)' }}>
                Export format
              </label>
              <RadioGroup.Root value={format} onValueChange={setFormat} className="space-y-2">
                {['json', 'csv', 'markdown'].map(fmt => (
                  <div key={fmt} className="flex items-center gap-3">
                    <RadioGroup.Item
                      value={fmt}
                      className="w-5 h-5 rounded-full border-2 border-border transition-colors data-[state=checked]:border-brand-orange"
                      style={{
                        borderColor: format === fmt ? 'var(--brand-orange)' : 'var(--border)'
                      }}
                    >
                      <RadioGroup.Indicator className="flex items-center justify-center w-full h-full relative after:content-[''] after:block after:w-2.5 after:h-2.5 after:rounded-full" style={{ '--indicator-color': 'var(--brand-orange)' } as React.CSSProperties}>
                        <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: 'var(--brand-orange)' }} />
                      </RadioGroup.Indicator>
                    </RadioGroup.Item>
                    <label className="text-sm uppercase tracking-wider cursor-pointer">
                      {fmt}
                    </label>
                  </div>
                ))}
              </RadioGroup.Root>
            </div>

            {/* Include Fields */}
            <div className="mb-6">
              <label className="block text-sm mb-3" style={{ color: 'var(--muted-foreground)' }}>
                Include fields
              </label>
              <div className="space-y-3">
                {Object.entries(includeFields).map(([field, checked]) => (
                  <div key={field} className="flex items-center gap-3">
                    <Checkbox.Root
                      checked={checked}
                      onCheckedChange={(checked) =>
                        setIncludeFields(prev => ({ ...prev, [field]: checked === true }))
                      }
                      className="w-5 h-5 rounded border-2 border-border flex items-center justify-center transition-colors data-[state=checked]:bg-brand-orange data-[state=checked]:border-brand-orange"
                      style={{
                        backgroundColor: checked ? 'var(--brand-orange)' : 'transparent',
                        borderColor: checked ? 'var(--brand-orange)' : 'var(--border)'
                      }}
                    >
                      <Checkbox.Indicator>
                        <svg width="12" height="12" viewBox="0 0 15 15" fill="none">
                          <path
                            d="M11.4669 3.72684C11.7558 3.91574 11.8369 4.30308 11.648 4.59198L7.39799 11.092C7.29783 11.2452 7.13556 11.3467 6.95402 11.3699C6.77247 11.3931 6.58989 11.3355 6.45446 11.2124L3.70446 8.71241C3.44905 8.48022 3.43023 8.08494 3.66242 7.82953C3.89461 7.57412 4.28989 7.55529 4.5453 7.78749L6.75292 9.79441L10.6018 3.90792C10.7907 3.61902 11.178 3.53795 11.4669 3.72684Z"
                            fill="white"
                          />
                        </svg>
                      </Checkbox.Indicator>
                    </Checkbox.Root>
                    <label className="text-sm cursor-pointer capitalize">
                      {field}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* RFP Name */}
            <div className="mb-6">
              <label className="block text-sm mb-2" style={{ color: 'var(--muted-foreground)' }}>
                RFP name
              </label>
              <input
                type="text"
                defaultValue="Sample RFP — Agent Engineering Challenge"
                className="w-full px-3 py-2 border border-border rounded-md focus:outline-none focus:ring-2 transition-all"
                style={{ '--tw-ring-color': 'var(--brand-orange)' } as React.CSSProperties}
              />
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <button
                onClick={handleDownload}
                className="w-full py-3 rounded-md flex items-center justify-center gap-2"
                style={{ backgroundColor: 'var(--brand-orange)', color: 'white' }}
              >
                <Download size={20} />
                Download rfp_output.json
              </button>
              <button
                onClick={handleCopy}
                className="w-full py-3 rounded-md border border-border flex items-center justify-center gap-2 transition-colors hover:bg-muted"
              >
                {copied ? (
                  <>
                    <CheckCircle2 size={20} style={{ color: 'var(--success)' }} />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy size={20} />
                    Copy to clipboard
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right - JSON Preview */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg mb-4">JSON Preview</h2>
            <div
              className="p-4 rounded-lg overflow-auto font-mono text-[13px] max-h-[600px]"
              style={{ backgroundColor: 'var(--brand-dark)', color: '#A5F3FC' }}
            >
              <pre className="whitespace-pre-wrap">
                {JSON.stringify(mockOutput, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
