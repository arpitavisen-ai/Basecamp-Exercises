import { useState } from 'react';
import { Upload, ArrowRight } from 'lucide-react';
import * as Tabs from '@radix-ui/react-tabs';

interface UploadScreenProps {
  onStart: (questions: string) => void;
}

const sampleQuestions = `Q1 | technical | Describe your platform's approach to real-time threat detection and how it integrates with existing security infrastructure.
Q2 | compliance | List all compliance certifications your organization currently maintains and their renewal dates.
Q3 | pricing | What is your pricing model for enterprise accounts with 500+ seats?
Q4 | technical | How does your SIEM integration work with popular platforms like Splunk and QRadar?
Q5 | company-info | Tell us about your company history, current team size, and key customer segments.`;

export function UploadScreen({ onStart }: UploadScreenProps) {
  const [activeTab, setActiveTab] = useState('paste');
  const [questions, setQuestions] = useState(sampleQuestions);

  const parseQuestions = (text: string) => {
    const lines = text.split('\n').filter(line => line.trim().startsWith('Q'));
    return lines.length;
  };

  const questionCount = parseQuestions(questions);

  const detectCategories = (text: string) => {
    const categories: Record<string, number> = {};
    const lines = text.split('\n').filter(line => line.trim().startsWith('Q'));
    lines.forEach(line => {
      const match = line.match(/\|\s*(\w+)\s*\|/);
      if (match) {
        const cat = match[1];
        categories[cat] = (categories[cat] || 0) + 1;
      }
    });
    return categories;
  };

  const categories = detectCategories(questions);

  return (
    <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: 'var(--surface)' }}>
      <div className="w-full max-w-[680px]">
        <div className="mb-8">
          <h1 className="text-[32px] font-bold mb-2" style={{ color: 'var(--brand-dark)' }}>
            Draft your RFP response in minutes
          </h1>
          <p className="text-[16px]" style={{ color: 'var(--muted-foreground)' }}>
            Paste questions below or upload a CSV
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <Tabs.Root value={activeTab} onValueChange={setActiveTab}>
            <Tabs.List className="flex gap-2 mb-6 border-b border-border">
              <Tabs.Trigger
                value="paste"
                className="px-4 py-2 data-[state=active]:border-b-2 transition-colors"
                style={{
                  borderColor: activeTab === 'paste' ? 'var(--brand-orange)' : 'transparent',
                  color: activeTab === 'paste' ? 'var(--brand-orange)' : 'var(--muted-foreground)'
                }}
              >
                Paste text
              </Tabs.Trigger>
              <Tabs.Trigger
                value="upload"
                className="px-4 py-2 data-[state=active]:border-b-2 transition-colors"
                style={{
                  borderColor: activeTab === 'upload' ? 'var(--brand-orange)' : 'transparent',
                  color: activeTab === 'upload' ? 'var(--brand-orange)' : 'var(--muted-foreground)'
                }}
              >
                Upload CSV
              </Tabs.Trigger>
            </Tabs.List>

            <Tabs.Content value="paste">
              <textarea
                value={questions}
                onChange={(e) => setQuestions(e.target.value)}
                className="w-full min-h-[200px] p-4 border border-border rounded-md resize-y focus:outline-none focus:ring-2 transition-all"
                style={{ '--tw-ring-color': 'var(--brand-orange)' } as React.CSSProperties}
                placeholder="Q1 | technical | Describe your platform's approach to real-time threat detection...&#10;Q2 | compliance | List all compliance certifications...&#10;Q3 | pricing | What is your pricing model for enterprise accounts?&#10;Q4 | technical | How does your SIEM integration work?&#10;Q5 | company-info | Tell us about your company history..."
              />
            </Tabs.Content>

            <Tabs.Content value="upload">
              <div className="border-2 border-dashed rounded-lg p-12 text-center" style={{ borderColor: 'var(--muted)' }}>
                <Upload className="mx-auto mb-4" size={48} style={{ color: 'var(--muted-foreground)' }} />
                <p style={{ color: 'var(--muted-foreground)' }}>
                  Drop CSV here or click to browse
                </p>
                <p className="text-xs mt-2" style={{ color: 'var(--muted-foreground)' }}>
                  Expected format: question_id, category, question_text
                </p>
              </div>
            </Tabs.Content>
          </Tabs.Root>

          {questionCount > 0 && (
            <div className="mt-4">
              <div className="inline-block px-3 py-1 rounded-full text-sm mb-3" style={{ backgroundColor: 'var(--muted)', color: 'var(--brand-dark)' }}>
                {questionCount} question{questionCount !== 1 ? 's' : ''} detected
              </div>

              {Object.keys(categories).length > 0 && (
                <div className="flex flex-wrap gap-2 mb-4">
                  {Object.entries(categories).map(([cat, count]) => (
                    <span
                      key={cat}
                      className="px-3 py-1 rounded-full text-xs uppercase tracking-wider"
                      style={{ backgroundColor: 'var(--accent)', color: 'var(--brand-dark)' }}
                    >
                      {cat} ×{count}
                    </span>
                  ))}
                </div>
              )}
            </div>
          )}

          <button
            onClick={() => onStart(questions)}
            disabled={questionCount === 0}
            className="w-full py-3 rounded-md flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              backgroundColor: questionCount > 0 ? 'var(--brand-orange)' : 'var(--muted)',
              color: 'white'
            }}
          >
            Run Agent
            <ArrowRight size={20} />
          </button>

          <p className="text-xs text-center mt-4" style={{ color: 'var(--muted-foreground)' }}>
            Powered by Claude claude-sonnet-4-20250514 · Knowledge base: 7 entries
          </p>
        </div>
      </div>
    </div>
  );
}
