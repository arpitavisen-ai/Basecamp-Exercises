import { useState } from 'react';
import { FileText, AlertTriangle, ChevronDown, Edit3, RotateCcw, Flag, X, Download, Printer, RefreshCw } from 'lucide-react';

interface Answer {
  question_id: string;
  category: string;
  question: string;
  answer: string;
  sources: string[];
  confidence: 'high' | 'medium' | 'low';
  flags: string[];
}

interface Issue {
  type: 'contradiction' | 'inconsistency' | 'tone_mismatch' | 'missing_info';
  questions_involved: string[];
  description: string;
  suggested_fix: string;
}

interface ReviewWorkspaceProps {
  onExport: () => void;
}

const mockAnswers: Answer[] = [
  {
    question_id: 'Q1',
    category: 'technical',
    question: 'Describe your platform\'s approach to real-time threat detection...',
    answer: 'Helios Sentinel employs a multi-layered approach to real-time threat detection combining signature-based detection, behavioral analysis, and machine learning models. Our platform achieves detection-to-alert latency of 2.3 seconds for signature matches and 18 seconds for anomaly-based detections across distributed endpoints.',
    sources: ['Helios Platform Architecture Doc v4.2', 'Acme Corp RFP Response — March 2024'],
    confidence: 'high',
    flags: [],
  },
  {
    question_id: 'Q2',
    category: 'compliance',
    question: 'List all compliance certifications...',
    answer: 'Helios Security maintains SOC 2 Type II, ISO 27001, HIPAA, and GDPR compliance certifications. Our annual audits are conducted by Deloitte with the most recent certification dated January 2026.',
    sources: ['Compliance Certifications Overview', 'Annual Audit Report 2026'],
    confidence: 'high',
    flags: [],
  },
  {
    question_id: 'Q3',
    category: 'pricing',
    question: 'What is your pricing model for enterprise accounts?',
    answer: 'Enterprise pricing starts at $24/user/month for our EPP+EDR bundle. SIEM integration is available as an add-on at $6/user/month. Volume discounts apply for deployments exceeding 500 seats.',
    sources: ['Pricing Sheet Q1 2026', 'Enterprise Sales Playbook'],
    confidence: 'medium',
    flags: [],
  },
  {
    question_id: 'Q4',
    category: 'technical',
    question: 'How does your SIEM integration work?',
    answer: 'Our SIEM integration uses standard syslog and CEF formats, with native connectors for Splunk, QRadar, and Azure Sentinel. For Meridian Bank, we deployed a fully integrated EPP+EDR+SIEM bundle that streams events in real-time.',
    sources: ['SIEM Integration Guide', 'Meridian Bank Case Study'],
    confidence: 'high',
    flags: [],
  },
  {
    question_id: 'Q5',
    category: 'company-info',
    question: 'Tell us about your company history...',
    answer: 'Founded in 2018, Helios Security has grown to serve over 200 enterprise customers across financial services, healthcare, and technology sectors. Our team of 150+ security experts operates from offices in San Francisco, Austin, and London.',
    sources: ['Company Overview', 'About Us Page'],
    confidence: 'low',
    flags: ['Low confidence — knowledge base did not contain sufficient information for this question.'],
  },
];

const mockReview = {
  status: 'issues_found' as const,
  overall_assessment: 'The responses demonstrate strong technical depth and compliance awareness. However, pricing inconsistencies between Q3 and Q4 require clarification. The company history answer lacks specific detail and may benefit from additional supporting evidence.',
  issues: [
    {
      type: 'contradiction' as const,
      questions_involved: ['Q3', 'Q4'],
      description: 'Q3 states SIEM as an add-on (+$6/seat/mo) but Q4\'s Meridian Bank reference shows it included in EPP+EDR+SIEM bundle.',
      suggested_fix: 'Clarify whether SIEM is bundled or add-on for enterprise accounts.',
    },
    {
      type: 'inconsistency' as const,
      questions_involved: ['Q5'],
      description: 'Company history lacks specific founding details and milestone achievements mentioned in other customer-facing materials.',
      suggested_fix: 'Add founding story, key product launches, and major customer wins.',
    },
  ],
};

export function ReviewWorkspace({ onExport }: ReviewWorkspaceProps) {
  const [answers] = useState<Answer[]>(mockAnswers);
  const [selectedSource, setSelectedSource] = useState<string | null>(null);
  const [highlightedQuestions, setHighlightedQuestions] = useState<string[]>([]);
  const [expandedAnswers, setExpandedAnswers] = useState<Set<string>>(new Set());

  const issueTypeColor = (type: string) => {
    switch (type) {
      case 'contradiction':
        return 'var(--error)';
      case 'inconsistency':
        return 'var(--warning)';
      case 'tone_mismatch':
        return '#60A5FA';
      case 'missing_info':
        return 'var(--muted-foreground)';
      default:
        return 'var(--muted-foreground)';
    }
  };

  const confidenceDisplay = (confidence: string) => {
    const dots = confidence === 'high' ? 3 : confidence === 'medium' ? 2 : 1;
    const color = confidence === 'high' ? 'var(--success)' : confidence === 'medium' ? 'var(--warning)' : 'var(--error)';
    return (
      <div className="flex items-center gap-1">
        <span className="text-xs uppercase tracking-wider" style={{ color }}>
          {confidence}
        </span>
        <div className="flex gap-0.5">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: i < dots ? color : 'var(--muted)' }}
            />
          ))}
        </div>
      </div>
    );
  };

  const scrollToQuestion = (id: string) => {
    setHighlightedQuestions([id]);
    setTimeout(() => setHighlightedQuestions([]), 3000);
  };

  const toggleExpanded = (id: string) => {
    setExpandedAnswers(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--surface)' }}>
      {/* Top Bar */}
      <div className="bg-white border-b border-border p-4">
        <div className="max-w-[1600px] mx-auto">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-xl" contentEditable suppressContentEditableWarning>
              Sample RFP — Agent Engineering Challenge
            </h1>
            <div className="flex gap-2">
              <button
                className="px-4 py-2 rounded-md border border-border flex items-center gap-2 transition-colors hover:bg-muted"
              >
                <RefreshCw size={16} />
                Re-run Agent
              </button>
              <button className="p-2 rounded-md border border-border transition-colors hover:bg-muted">
                <Printer size={16} />
              </button>
              <button
                onClick={onExport}
                className="px-4 py-2 rounded-md flex items-center gap-2"
                style={{ backgroundColor: 'var(--brand-orange)', color: 'white' }}
              >
                <Download size={16} />
                Export JSON
              </button>
            </div>
          </div>
          <div className="flex gap-4 text-sm" style={{ color: 'var(--muted-foreground)' }}>
            <span>5 questions</span>
            <span>·</span>
            <span style={{ color: 'var(--success)' }}>24/24 evals passed</span>
            <span>·</span>
            <span style={{ color: 'var(--warning)' }}>2 consistency issues</span>
            <span>·</span>
            <span>~60s total</span>
          </div>
        </div>
      </div>

      {/* Three-panel layout */}
      <div className="max-w-[1600px] mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Panel 3a - Answer Cards */}
          <div className="space-y-4 max-h-[calc(100vh-200px)] overflow-y-auto pr-2">
            {answers.map(answer => {
              const isExpanded = expandedAnswers.has(answer.question_id);
              const answerPreview = answer.answer.length > 200 && !isExpanded
                ? answer.answer.substring(0, 200) + '...'
                : answer.answer;
              const isHighlighted = highlightedQuestions.includes(answer.question_id);

              return (
                <div
                  key={answer.question_id}
                  className="bg-white rounded-lg shadow-md overflow-hidden transition-all"
                  style={{
                    borderLeft: answer.flags.length > 0 ? '4px solid var(--warning)' : isHighlighted ? '4px solid var(--brand-orange)' : 'none'
                  }}
                >
                  {/* Header */}
                  <div className="p-4 border-b border-border flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-bold">{answer.question_id}</span>
                      <span
                        className="px-2 py-0.5 rounded text-xs uppercase tracking-wider"
                        style={{ backgroundColor: 'var(--muted)', color: 'var(--brand-dark)' }}
                      >
                        {answer.category}
                      </span>
                    </div>
                    {confidenceDisplay(answer.confidence)}
                  </div>

                  {/* Question */}
                  <div className="px-4 pt-3 pb-2">
                    <p className="text-sm line-clamp-2" style={{ color: 'var(--muted-foreground)' }}>
                      {answer.question}
                    </p>
                  </div>

                  {/* Flags */}
                  {answer.flags.length > 0 && (
                    <div className="mx-4 mb-2 p-3 rounded-md flex items-start gap-2" style={{ backgroundColor: '#FEF3C7' }}>
                      <AlertTriangle size={16} style={{ color: 'var(--warning)' }} className="mt-0.5 flex-shrink-0" />
                      <p className="text-sm" style={{ color: '#92400E' }}>
                        {answer.flags[0]}
                      </p>
                    </div>
                  )}

                  {/* Answer */}
                  <div className="px-4 pb-3">
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">
                      {answerPreview}
                    </p>
                    {answer.answer.length > 200 && (
                      <button
                        onClick={() => toggleExpanded(answer.question_id)}
                        className="text-sm mt-2 flex items-center gap-1 transition-colors"
                        style={{ color: 'var(--brand-orange)' }}
                      >
                        {isExpanded ? 'Show less' : 'Show more'}
                        <ChevronDown size={16} className={isExpanded ? 'rotate-180 transition-transform' : 'transition-transform'} />
                      </button>
                    )}
                  </div>

                  {/* Sources */}
                  <div className="px-4 pb-3 border-t border-border pt-3">
                    <p className="text-sm mb-2" style={{ color: 'var(--muted-foreground)' }}>Sources:</p>
                    <div className="flex flex-wrap gap-2">
                      {answer.sources.map((source, i) => (
                        <button
                          key={i}
                          onClick={() => setSelectedSource(source)}
                          className="px-3 py-1.5 rounded-full text-sm flex items-center gap-2 transition-colors hover:opacity-80"
                          style={{ backgroundColor: 'var(--accent)', color: 'var(--brand-dark)' }}
                        >
                          <FileText size={14} />
                          {source}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="px-4 pb-4 flex gap-2">
                    <button className="px-3 py-1.5 rounded-md text-sm border border-border flex items-center gap-1 transition-colors hover:bg-muted">
                      <Edit3 size={14} />
                      Edit answer
                    </button>
                    <button className="px-3 py-1.5 rounded-md text-sm border border-border flex items-center gap-1 transition-colors hover:bg-muted">
                      <RotateCcw size={14} />
                      Regenerate
                    </button>
                    <button className="px-3 py-1.5 rounded-md text-sm border border-border flex items-center gap-1 transition-colors hover:bg-muted">
                      <Flag size={14} />
                      Flag for review
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Panel 3b - Consistency Review */}
          <div className="space-y-4">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg">Consistency Review</h2>
                <span
                  className="px-3 py-1 rounded-full text-xs uppercase tracking-wider"
                  style={{
                    backgroundColor: mockReview.status === 'pass' ? 'var(--success)' : 'var(--warning)',
                    color: 'white'
                  }}
                >
                  {mockReview.status === 'pass' ? 'pass' : 'issues found'}
                </span>
              </div>

              <div className="p-4 rounded-md mb-6" style={{ backgroundColor: 'var(--surface)' }}>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>
                  {mockReview.overall_assessment}
                </p>
              </div>

              <div className="space-y-4">
                {mockReview.issues.map((issue, i) => (
                  <div key={i} className="border border-border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <span
                        className="px-2 py-1 rounded text-xs uppercase tracking-wider"
                        style={{
                          backgroundColor: issueTypeColor(issue.type),
                          color: 'white'
                        }}
                      >
                        {issue.type}
                      </span>
                      <div className="flex gap-1">
                        {issue.questions_involved.map(q => (
                          <span
                            key={q}
                            className="px-2 py-0.5 rounded text-xs"
                            style={{ backgroundColor: 'var(--muted)', color: 'var(--brand-dark)' }}
                          >
                            {q}
                          </span>
                        ))}
                      </div>
                    </div>

                    <p className="text-sm mb-3">{issue.description}</p>

                    <div className="p-3 rounded-md mb-3" style={{ backgroundColor: 'var(--surface)' }}>
                      <p className="text-sm font-medium mb-1">Suggested fix:</p>
                      <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
                        {issue.suggested_fix}
                      </p>
                    </div>

                    <div className="flex gap-2">
                      {issue.questions_involved.map(q => (
                        <button
                          key={q}
                          onClick={() => scrollToQuestion(q)}
                          className="px-3 py-1.5 rounded-md text-sm transition-colors"
                          style={{ backgroundColor: 'var(--brand-orange)', color: 'white' }}
                        >
                          Go to {q}
                        </button>
                      ))}
                      <button className="px-3 py-1.5 rounded-md text-sm border border-border transition-colors hover:bg-muted">
                        Dismiss
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Source Evidence Drawer */}
      {selectedSource && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-end z-50" onClick={() => setSelectedSource(null)}>
          <div
            className="bg-white h-full w-full max-w-[500px] p-6 overflow-y-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                <FileText size={24} style={{ color: 'var(--brand-orange)' }} />
                <h2 className="text-lg">{selectedSource}</h2>
              </div>
              <button onClick={() => setSelectedSource(null)}>
                <X size={24} />
              </button>
            </div>

            <div className="border border-border rounded-lg p-4 mb-6" style={{ backgroundColor: 'var(--surface)' }}>
              <p className="text-sm leading-relaxed">
                This document contains detailed information about the Helios platform architecture,
                including real-time threat detection capabilities, system latency benchmarks,
                and integration patterns with enterprise security infrastructure...
              </p>
            </div>

            <div className="mb-4">
              <p className="text-sm mb-2" style={{ color: 'var(--muted-foreground)' }}>
                Used in: Q1, Q4
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              {['technical', 'detection', 'latency'].map(tag => (
                <span
                  key={tag}
                  className="px-3 py-1 rounded-full text-xs uppercase tracking-wider"
                  style={{ backgroundColor: 'var(--muted)', color: 'var(--brand-dark)' }}
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
