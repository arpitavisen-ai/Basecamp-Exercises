import { useState } from 'react';
import { CheckCircle2, Circle, User } from 'lucide-react';
import { UploadScreen } from './components/UploadScreen';
import { ProcessingScreen } from './components/ProcessingScreen';
import { ReviewWorkspace } from './components/ReviewWorkspace';
import { ExportScreen } from './components/ExportScreen';

type Screen = 'upload' | 'processing' | 'review' | 'export';

const steps = [
  { id: 'upload', label: 'Input' },
  { id: 'processing', label: 'Processing' },
  { id: 'review', label: 'Review' },
  { id: 'export', label: 'Export' },
];

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('upload');

  const currentStepIndex = steps.findIndex(s => s.id === currentScreen);

  const handleStart = (questions: string) => {
    setCurrentScreen('processing');
  };

  const handleProcessingComplete = () => {
    setCurrentScreen('review');
  };

  const handleExport = () => {
    setCurrentScreen('export');
  };

  const handleBackToReview = () => {
    setCurrentScreen('review');
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Navigation Bar */}
      <div className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: 'var(--brand-orange)' }}>
                <span className="text-white font-bold text-lg">H</span>
              </div>
              <span className="font-bold text-lg" style={{ color: 'var(--brand-dark)' }}>
                Helios RFP Agent
              </span>
            </div>

            {/* Step Indicator */}
            <div className="flex items-center gap-2">
              {steps.map((step, index) => {
                const isActive = index === currentStepIndex;
                const isCompleted = index < currentStepIndex;

                return (
                  <div key={step.id} className="flex items-center gap-2">
                    <div className="flex items-center gap-2">
                      {isCompleted ? (
                        <CheckCircle2 size={20} style={{ color: 'var(--brand-orange)' }} />
                      ) : (
                        <Circle
                          size={20}
                          style={{
                            color: isActive ? 'var(--brand-orange)' : 'var(--muted-foreground)',
                            fill: isActive ? 'var(--brand-orange)' : 'transparent'
                          }}
                        />
                      )}
                      <span
                        className="text-sm"
                        style={{
                          color: isActive ? 'var(--brand-orange)' : isCompleted ? 'var(--brand-dark)' : 'var(--muted-foreground)',
                          fontWeight: isActive ? 500 : 400
                        }}
                      >
                        {step.label}
                      </span>
                    </div>
                    {index < steps.length - 1 && (
                      <span style={{ color: 'var(--muted-foreground)' }}>→</span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* User Avatar */}
            <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: 'var(--muted)' }}>
              <User size={18} style={{ color: 'var(--brand-dark)' }} />
            </div>
          </div>
        </div>
      </div>

      {/* Screen Content */}
      <div className="flex-1">
        {currentScreen === 'upload' && <UploadScreen onStart={handleStart} />}
        {currentScreen === 'processing' && <ProcessingScreen onComplete={handleProcessingComplete} />}
        {currentScreen === 'review' && <ReviewWorkspace onExport={handleExport} />}
        {currentScreen === 'export' && <ExportScreen onBack={handleBackToReview} />}
      </div>
    </div>
  );
}